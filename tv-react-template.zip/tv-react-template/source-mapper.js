module.exports = {
  tizen: [
    "<link rel='stylesheet' href='./font.css' type='text/css' />",
    "<link rel='stylesheet' type='text/css' href='./build.css' />",
    "<script src='$WEBAPIS/webapis/webapis.js'></script>",
    "<script src='./build.js'></script>"
    
  ],
  lg: [
    "<link rel='stylesheet' href='./font.css' type='text/css' />",
    "<link rel='stylesheet' type='text/css' href='./build.css' />",
    "<script src='./webOS.js'></script>",
    "<script src='./build.js'></script>"
  ],
  web: [
    "<link rel='stylesheet' href='./font.css' type='text/css' />",
    "<link rel='stylesheet' type='text/css' href='./build.css' />",
    "<script src='./build.js'></script>"
  ]
};
