const getPlatform = platform => {
    const platformData = {
      tizen: [
        {
          from: `src/platforms/${platform}/.settings`,
          to: './.settings'
        },
        {
          from: `src/platforms/${platform}/.project`,
          to: './'
        },
        {
          from: `./src/platforms/${platform}/.tproject`,
          to: './'
        },
        {
          from: `src/platforms/${platform}/config.xml`,
          to: './config.xml'
        },
        {
          from: `src/platforms/${platform}/icon.png`,
          to: './icon.png'
        },
        {
          from: `src/platforms/${platform}/script/key.js`,
          to: '../src/utils/key.js'
        },
        {
          from: `src/platforms/${platform}/script/generic.js`,
          to: '../src/utils/generic.js'
        }
      ],
      lg: [
        {
          from: `src/platforms/${platform}/.settings`,
          to: './.settings'
        },
        {
          from: `src/platforms/${platform}/.project`,
          to: './'
        },
        {
          from: `src/platforms/${platform}/appinfo.json`,
          to: './appinfo.json'
        },
        {
          from: `src/platforms/${platform}/webOSTV.js`,
          to: './webOS.js'
        },
        {
          from: `src/platforms/${platform}/icon.png`,
          to: './icon.png'
        },
        {
          from: `src/platforms/${platform}/largeIcon.png`,
          to: './largeIcon.png'
        },
        {
          from: `src/platforms/${platform}/script/key.js`,
          to: '../src/utils/key.js'
        },
        {
          from: `src/platforms/${platform}/script/generic.js`,
          to: '../src/utils/generic.js'
        }
      ],
      web: [
        {
          from: `src/platforms/${platform}/script/key.js`,
          to: '../src/utils/key.js'
        },
        {
          from: `src/platforms/${platform}/script/generic.js`,
          to: '../src/utils/generic.js'
        }
      ]
    };
    return platformData[platform];
  };
  
  module.exports = getPlatform;
  