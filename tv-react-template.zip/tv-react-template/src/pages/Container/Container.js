import React, {Fragment} from 'react';
import {Route, Switch} from 'react-router-dom';
import {bindActionCreators, compose} from 'redux';
import {connect} from 'react-redux';

import {NextRoutes} from '../../routes';

import Splash from '../Splash';
import Home from '../Home';

const Container = props => {
    return (
        <Fragment>
            <Switch>
                {NextRoutes.map(route => {
                    return (
                        <Route
                            key={route.key}
                            path={route.path}
                            component={route.component}
                            history={props.history}
                        />
                    );
                })}

                <Route
                    exact
                    path={props.match.url}
                    component={props.splash.splash ? Splash : Home}
                    history={props.history}
                />
            </Switch>
        </Fragment>
    );
};

const mapStateToProps = state => ({
    splash: state.splash
});

const mapDispatchToProps = dispatch => {
    return bindActionCreators({}, dispatch);
};

export default compose(
    connect(
        mapStateToProps,
        mapDispatchToProps
    )
)(Container);
