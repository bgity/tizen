import React, { PureComponent } from "react";
import { bindActionCreators, compose } from "redux";
import { connect } from "react-redux";

import "./index.scss";
import Loader from "../../components/Loader";

class Home extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() { /* TODO document why this method 'componentDidMount' is empty */ }

  componentDidUpdate() { /* TODO document why this method 'componentDidUpdate' is empty */ }

  componentWillUnmount() { /* TODO document why this method 'componentWillUnmount' is empty */ }

  render() {
    return (
      <div className="home-container" >
         Home Page
      </div>
    );
  }
}

const mapStateToProps = (state) => ({});

const mapDispatchToProps = (dispatch) => {
  return bindActionCreators({}, dispatch);
};

export default compose(connect(mapStateToProps, mapDispatchToProps))(Home);
