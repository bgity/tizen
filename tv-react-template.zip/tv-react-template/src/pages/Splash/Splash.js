import React,{useEffect} from 'react';
import {bindActionCreators, compose} from 'redux';
import {connect} from 'react-redux';

import {hideSplash} from '../../modules/splash/splash.actions';
import './index.scss'

const Splash = (props) => {

    useEffect(()=>{
     },[]);
   
    setTimeout(() => {
      props.hideSplash({splash: false});
    }, 5000);
    return (
        <div className="splash-page">
            Spalsh Screen
        </div>
    );
};

const mapStateToProps = state => ({});

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        hideSplash
    }, dispatch);
};

export default compose(
    connect(
        mapStateToProps,
        mapDispatchToProps
    )
)(Splash);
