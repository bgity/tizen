export const exit =()=>{
    tizen.application.getCurrentApplication().exit();
};

export const getNetworkStatus = () => {
    return window.navigator.onLine;
};

