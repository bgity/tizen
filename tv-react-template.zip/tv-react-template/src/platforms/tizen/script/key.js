try{
    tizen.tvinputdevice.registerKey('MediaPlay');
    tizen.tvinputdevice.registerKey('MediaPause');
    tizen.tvinputdevice.registerKey('MediaFastForward');
    tizen.tvinputdevice.registerKey('MediaRewind');
    tizen.tvinputdevice.registerKey('MediaPlayPause');
    tizen.tvinputdevice.registerKey('MediaStop');
    tizen.tvinputdevice.registerKey('MediaTrackNext');
}catch (e) {}
const KEY = {};
KEY.LEFT = 37;
KEY.UP = 38;
KEY.RIGHT = 39;
KEY.DOWN = 40;
KEY.ENTER = 13;
KEY.BACK = 10009;
KEY.PAUSE = 19;
KEY.PLAY = 415;
KEY.PLAY_PAUSE = 10252;
KEY.STOP = 413;
KEY.DONE=65376;
KEY.FORWARD=417;
KEY.REWIND=412;
KEY.NEXT=10233;

export default KEY;
