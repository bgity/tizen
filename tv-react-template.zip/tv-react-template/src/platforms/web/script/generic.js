export const exit =()=>{
    window.close();
};

export const getNetworkStatus = () => {
    return window.navigator.onLine;
};
