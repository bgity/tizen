const KEY = {};
KEY.LEFT = 37;
KEY.UP = 38;
KEY.RIGHT = 39;
KEY.DOWN = 40;
KEY.ENTER = 13;
KEY.BACK = 8;

export default KEY;