const initialState = { splash: true };

export default (state = initialState, action) => {
  switch (action.type) {
    case 'HIDE_SPLASH':
      return { ...state, splash: action.splash };
    default:
      return state;
  }
};
