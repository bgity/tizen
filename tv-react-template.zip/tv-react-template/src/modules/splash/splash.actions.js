export const hideSplash = splash => ({
  type: 'HIDE_SPLASH',
  ...splash
});
