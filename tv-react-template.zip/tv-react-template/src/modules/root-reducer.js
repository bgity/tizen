import {combineReducers} from 'redux';
import {connectRouter} from 'connected-react-router';

import splash from './splash/splash.reducer';

export default function (history) {
    return combineReducers({
        splash,
        router: connectRouter(history)
    });
}
