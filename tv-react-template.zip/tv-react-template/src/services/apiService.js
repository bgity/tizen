import axios from 'axios';

export const get = (url) => {
    return axios.get(url);
};

export const post = (url) => {
    return axios.post(url);
};

export const put = (url) => {
    return axios.put(url);
};

export const del = (url) => {
    return axios.delete(url);
};


