import Container from './pages/Container';
import Home from './pages/Home';

export const NextRoutes = [
    {
        path: '/home',
        component: Home,
        key: 'home'
    }
];

export const BaseRoutes = [
    {
        path: '/',
        component: Container,
        key: 'root'
    },
    {
        path: '',
        component: Container,
        key: 'root'
    }
];
