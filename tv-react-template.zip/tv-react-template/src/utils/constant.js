const CONSTANTS = {};

export default CONSTANTS;
