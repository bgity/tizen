import React from 'react';
import { HashRouter, Route, Switch } from 'react-router-dom';

import createBrowserHistory from 'history/createBrowserHistory';
import { BaseRoutes } from './routes';

const history = createBrowserHistory();

export default () => {
  return (
    <HashRouter history={history}>
      <Switch>
        {BaseRoutes.map(route => {
          return (
            <Route
              key={route.key}
              exact
              path={route.path}
              component={route.component}
            />
          );
        })}
      </Switch>
    </HashRouter>
  );
};
